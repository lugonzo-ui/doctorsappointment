<?php include('header.php'); ?>





	<!-- this is for donor registraton -->
	<div class="main_content" style="background-color:#fff;">
		<h3 class="text-center" style="background-color:#272327;color: #fff;">About Us</h3>
		<div class="col-md-12">
			<div class="col-md-6">
				<img src="img/aboutimag33.jpg" alt="" class="img-responsive">
			</div>

			<div class="col-md-6">
				<article>
					<h3 style="color:#0616BC;">We are Beside you</h3>
					<p class="text-justify">Lorem ipsum dolor sit amet, 
					consectetur adipiscing elit.
					 They do not know, and the pains, nor during these symptoms.
					  Labor, often called hate like the blind draw takes advantage of pain,
					   but also happy because no facilis.lorem
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
					 You contain the whole,
                     and sorrows, a man who is wise, therefore,
					  anything that has been enhanced and explorer of the time. 
					  They have regular big blind, who are often painful to completely hate welcome
                    Lorem ipsum dolor sit amet, 
					consectetur adipiscing elit. 
					You contain the whole, and sorrows,
					 a man who is wise, therefore, 
					 anything that has been enhanced and explorer of the time. 
					 They have regular big blind, who are often painful to completely hate welcome.</p>
				</article>
			</div>
		</div>


		<div class="col-md-12">
			<div class="col-md-6">
				<article>
					<h3 style="color:#0616BC;">24/7 hour service</h3>
					<p class="text-justify">Lorem ipsum dolor sit amet,
					 consectetur adipiscing elit.
					  They do not know, and the pains, nor during these symptoms.
					   Labor, often called hate like the blind draw takes advantage of pain,
					    but also happy because no facilis.
						lorem lorem ipsum carrots, enhanced rebates.
						 You contain the whole, and sorrows, 
						 a man who is wise, therefore, 
						 anything that has been enhanced and explorer of the time.
						  They have regular big blind, 
						  who are often painful to completely hate welcome lorem ipsum carrots,
						   enhanced rebates. You contain the whole, and sorrows, 
						   a man who is wise, therefore, anything that has been enhanced and explorer of the time.
						    They have regular big blind, who are often painful to completely hate welcome.</p>
				</article>
			</div>
			<div class="col-md-6">
				<img src="img/aboutimag11.jpg" alt="" class="img-responsive"><br>
			</div>
		</div>
          
    </div>
		
	
	
	

	
 <?php include('footer.php'); ?>


	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>





	
</body>
</html>