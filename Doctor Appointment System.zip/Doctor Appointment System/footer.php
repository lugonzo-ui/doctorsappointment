   <!-- footer section --> 
			<footer>
				<div class="col-md-12 fsection">
					<div class="col-md-4" id="contact">
					<p>Category</p> <hr>
					<ul>
						<li><a href="signin.php">Search for Doctors</a></li>
						<li><a href="signin.php">Contact with Doctors</a></li>
						
					</ul>
					</div>
					<div class="col-md-4">
						<p>Contact</p> <hr>
						<p>DR Paul anami <br>
							paulanami65@gmail.com <br>
							Cell: 0702461077</p>
							<span style="color: red;font-size: 15px">&copy;<?php echo date('Y'); ?>-All Rights Reserved</span>
					</div>
					<div class="col-md-4 share_img">
					<p>Link With</p> <hr>
						<a href="" ><img src="img/fb-free.png" alt="facebok"></a>
						<a href=""><img src="img/gogle-plud-free.png" alt="google-plus"></a>
						<a href=""><img src="img/twitter.png" alt="twitter"></a>
						
					</div>
				</div>
				

			</footer>

		<!-- footer section Ends--> 
